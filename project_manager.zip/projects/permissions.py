from django.core.exceptions import PermissionDenied
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import get_object_or_404
from .models import Project, ProjectMembership, Task

class ProjectMembershipMixin(LoginRequiredMixin):
    """Restrict queryset to projects where the user is a member."""
    def get_project(self):
        if hasattr(self, 'object') and isinstance(self.object, Project):
            return self.object
        pk = self.kwargs.get('pk') or self.kwargs.get('project_pk')
        if pk:
            return get_object_or_404(Project, pk=pk)
        # For task views: derive from object
        return None

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        return qs.filter(memberships__user=user)

class OwnerRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        project = None
        obj = getattr(self, 'object', None)
        if obj is not None:
            if hasattr(obj, 'project'):
                project = obj.project
            elif hasattr(obj, 'owner'):
                project = obj
        if project is None:
            project = get_object_or_404(Project, pk=self.kwargs.get('pk'))
        return ProjectMembership.objects.filter(project=project, user=self.request.user, role=ProjectMembership.Role.OWNER).exists()

class MemberRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        project = None
        obj = getattr(self, 'object', None)
        if obj is not None:
            if hasattr(obj, 'project'):
                project = obj.project
            elif hasattr(obj, 'owner'):
                project = obj
        if project is None:
            project = get_object_or_404(Project, pk=self.kwargs.get('pk') or self.kwargs.get('project_pk'))
        return ProjectMembership.objects.filter(project=project, user=self.request.user).exists()
